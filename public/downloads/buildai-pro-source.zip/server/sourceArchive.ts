import AdmZip from 'adm-zip';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');

export function createSourceCodeZip(): Buffer {
  const zip = new AdmZip();

  const includeFiles = [
    'package.json',
    'tsconfig.json',
    'vite.config.ts',
    'index.html',
    '.env.example',
    '.gitignore',
    'metadata.json',
    'README.md',
    'server.ts',
  ];

  const includeDirs = ['src', 'server'];

  // Add individual root files
  for (const fileName of includeFiles) {
    const filePath = path.join(ROOT_DIR, fileName);
    if (fs.existsSync(filePath)) {
      zip.addLocalFile(filePath, '');
    }
  }

  // Add directories recursively, skipping any database files or node_modules
  for (const dirName of includeDirs) {
    const dirPath = path.join(ROOT_DIR, dirName);
    if (fs.existsSync(dirPath)) {
      zip.addLocalFolder(dirPath, dirName);
    }
  }

  return zip.toBuffer();
}
